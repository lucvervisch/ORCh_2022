
#include "read_write/chemkin.h"


int main(int argc, char *argv[])
{

   string mech = argv[1];
   cout << "Mech: " << argv[1] << endl;
   cout << "Mech: " << mech << endl;
   
   Chemkin *c = new Chemkin();
   c->Write_ck_file(mech);




}


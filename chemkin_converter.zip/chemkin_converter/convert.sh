echo ""
echo "Type XML to input a .scheme file and get a .xml result"
echo "Type CK to input a .xml file and get a .scheme result"
echo ""

read XML_or_CK

if [ "$XML_or_CK" = "XML" ]; then 

   ls
   
   echo ""
   echo "----------"
   echo "Make sure the files are written with the same name"
   echo "and with the extension .scheme .therm and .trans"
   echo "----------"
   echo ""
   
   echo "Name of the file ?"
   read scheme_name
   
   #$HOME/gt_comb/cantera/build/bin/x86_64-unknown-linux-gnu/ck2cti -i $scheme_name.scheme -t $scheme_name.therm -tr $scheme_name.trans
    $HOME/anaconda/bin/ck2cti -i $scheme_name.scheme -t $scheme_name.thermo -tr $scheme_name.trans
   
   ls
   
   python ~/anaconda3/lib/python3.8/site-packages/cantera/ctml_writer.py $scheme_name.cti

fi;






if [ "$XML_or_CK" = "CK" ]; then

   echo "Name of the xml file ?"
   
   read scheme_name 
   
   $HOME/workdir/chemkin_converter/wchemkin $scheme_name.xml

fi;


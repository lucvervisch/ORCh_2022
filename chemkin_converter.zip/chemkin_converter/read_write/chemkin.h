#ifndef Chemkin_H
#define Chemkin_H

#include "read.h"

using namespace std;



//--------------------
class Chemkin
{
   public:
   //constructeur
   Chemkin();

   virtual void Write_ck_file(string mech) const;

   //destructeur
   virtual ~Chemkin();


   private:




};






#endif


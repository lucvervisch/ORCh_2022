#ifndef Species_H
#define Species_H

#include <iostream>
#include <vector>

using namespace std;


//--------------------
class Species
{
   public:
   //constructeur
   Species(string Name, string Description, 
           vector<double> NASACoeffs_lowT, double NASA_lowT_min, double NASA_lowT_max,
           vector<double> NASACoeffs_highT, double NASA_highT_min, double NASA_highT_max,
           bool QSS); 

   //destructeur
   virtual ~Species();

   public:
   string m_Name;
   string m_Description; //This is a copy of the species description from the xml file

   vector<double> m_NASACoeffs_lowT;
   double m_NASA_lowT_min;
   double m_NASA_lowT_max;
   vector<double> m_NASACoeffs_highT;
   double m_NASA_highT_min;
   double m_NASA_highT_max;

   bool m_QSS;

};


#endif


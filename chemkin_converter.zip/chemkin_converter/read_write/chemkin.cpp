#include <fstream>
#include <cstdlib>

#include "chemkin.h"
#include <math.h>

//---Chemkin---

Chemkin::Chemkin() //Constructeur
{}


void Chemkin::Write_ck_file(string mech) const
{
   vector<Species*> listSpecies;
   vector<Reaction*> listReactions;

   Read *r = new Read();
   r->Read_species(mech, listSpecies);
   r->Read_reactions(mech, listReactions);

   string file_name = mech.substr(0, mech.size()-4);
   file_name.append(".scheme");

   ofstream write_file(file_name.c_str(), ofstream::out);

   //Add the phase 
   write_file << "ELEMENTS" << endl;
   write_file << "O  H  C";

   for (unsigned int k=0; k<listSpecies.size(); k++)
   { 
      if (listSpecies[k]->m_Name == "N2")
         write_file << "  N";

      if (listSpecies[k]->m_Name == "AR")
         write_file << "  Ar";
	// Modified by Huu-Tri NGUYEN - Decembre 2018  
      if (listSpecies[k]->m_Name == "CF4")
         write_file << "  F";
 	//-----------  END ----------- 
   }
   write_file << endl;
   write_file << "END" << endl;




   write_file << "SPECIES" << endl;
   write_file << "    ";
   int countSpecies = 0;
   for (unsigned int k=0; k<listSpecies.size(); k++)
   {
      write_file << listSpecies[k]->m_Name << "  ";

      if ((countSpecies+1)%10 == 0)
         write_file << endl << "    ";

      countSpecies += 1;
   }
   write_file << endl << "END" << endl;




   write_file << " ! THERMO" << endl;
   write_file << " ! Insert GRI-Mech thermodynamics here or use in default file" << endl;
   write_file << " ! END" << endl;

   write_file << "REACTIONS" << endl;
   for (unsigned int j=0; j<listReactions.size(); j++)
   {

      string eq = listReactions[j]->m_equation;

      size_t blank = eq.find(" ");
      while (blank < 10000)
      {
         eq.erase(blank, 1);
         blank = eq.find(" ");
      }

      size_t left = eq.find("[");
      if (left < 10000)
         eq.replace(left, 1, "<");

      size_t right = eq.find("]");
      if (right < 10000)
         eq.replace(right, 1, ">");


      cout << "equation " << eq << endl;



      write_file << eq << "                     ";

      double n_moles = 0;
      for (unsigned int k=0; k<listReactions[j]->m_ReactantStoichCoeffs.size(); k++)
      {
         n_moles = n_moles+listReactions[j]->m_ReactantStoichCoeffs[k];
      }

      cout << listReactions[j]->m_equation << "  n_moles : " << n_moles << endl;

      double coeff = 1;
	// Default code - Commented by Huu-Tri NGUYEN - 22 February 2019
   //   if (n_moles == 1)
   //      coeff = 1;
   //   if (n_moles == 2)
   //      coeff = 1000;
   //   if (n_moles == 3)
   //      coeff = 1000000;
	//-----------  END Default Code ----------- 

	// Modified by Huu-Tri NGUYEN - 22 February 2019
         coeff = pow(10,3*(n_moles-1));

cout << "coef = " << coeff << endl;
	//-----------  END ----------- 
      if ((dynamic_cast <ThreeBody *> (listReactions[j])))
      {
         coeff = coeff*1000;
	 cout << "coef ThreeBody = " << coeff << endl; // Huu-Tri NGUYEN - 22 Feb 2019
      }

      if ((dynamic_cast <FalloffR *> (listReactions[j])))
      {
         coeff = coeff/1000;
	 cout << "coef FallOff = " << coeff << endl;	// Huu-Tri NGUYEN - 22 Feb 2019
	// Huu-Tri NGUYEN : In case of FallOf, there is also (+M) so the code initially recognizes this reaction as ThreeBody (coeff*1000), so we have to /1000 to return the correct coeff.
      }


      write_file << coeff*listReactions[j]->m_A << "             ";
      

      write_file << listReactions[j]->m_b << "            ";
      if (listReactions[j]->m_Etype == "cal/mol")
         write_file << listReactions[j]->m_E << endl;
      if (listReactions[j]->m_Etype == "J/mol")
         write_file << listReactions[j]->m_E/4.1868 << endl;

      if (listReactions[j]->m_duplicate)
      {
         write_file << " DUPLICATE" << endl;
      }

      if (dynamic_cast <FalloffR *> (listReactions[j]))
      {
         write_file << "  LOW  /  " << 1000000*(dynamic_cast <FalloffR *> (listReactions[j]))->m_A_low << "  ";
         write_file << (dynamic_cast <FalloffR *> (listReactions[j]))->m_b_low << "  ";
         if (listReactions[j]->m_Etype == "cal/mol")
            write_file << (dynamic_cast <FalloffR *> (listReactions[j]))->m_E_low << "/" << endl;
         if (listReactions[j]->m_Etype == "J/mol")
            write_file << (dynamic_cast <FalloffR *> (listReactions[j]))->m_E_low/4.1868 << "/" << endl;
      }

      if (dynamic_cast <Troe *> (listReactions[j]))
      {
         write_file << "  TROE/  ";
         for (unsigned int k=0; k<(dynamic_cast <Troe *> (listReactions[j]))->m_TroeCoeffs.size(); k++)
         {
            write_file << (dynamic_cast <Troe *> (listReactions[j]))->m_TroeCoeffs[k];
            if (k<(dynamic_cast <Troe *> (listReactions[j]))->m_TroeCoeffs.size()-1)
               write_file << " ";
         }
         write_file << "/" << endl;
      }

      if (dynamic_cast <ThreeBody *> (listReactions[j]))
      {
         for (unsigned int k=0; k<(dynamic_cast <ThreeBody *> (listReactions[j]))->m_TBconc.size(); k++)
         {

            write_file << (dynamic_cast <ThreeBody *> (listReactions[j]))->m_NameTBconc[k] << "/";
            write_file << (dynamic_cast <ThreeBody *> (listReactions[j]))->m_TBconc[k] << "/ ";
               if (k<(dynamic_cast <ThreeBody *> (listReactions[j]))->m_TBconc.size()-1)
                  write_file << "  ";
         }
         write_file << endl;
      }
  






   }
   write_file << "END" << endl;
   write_file.close();








}











Chemkin::~Chemkin() //Destructeur
{}




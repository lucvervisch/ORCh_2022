#include "species.h"

//---Species---

Species::Species(string Name, string Description,
           vector<double> NASACoeffs_lowT, double NASA_lowT_min, double NASA_lowT_max,
           vector<double> NASACoeffs_highT, double NASA_highT_min, double NASA_highT_max,
           bool QSS) //Constructeur
   :m_Name(Name), m_Description(Description),
    m_NASACoeffs_lowT(NASACoeffs_lowT), 
    m_NASA_lowT_min(NASA_lowT_min), m_NASA_lowT_max(NASA_lowT_max),
    m_NASACoeffs_highT(NASACoeffs_highT), 
    m_NASA_highT_min(NASA_highT_min), m_NASA_highT_max(NASA_highT_max),
    m_QSS(QSS)
{}

Species::~Species() //Destructeur
{}


